# Inverted-Pendulum-Simulink
This is Simulation of Inverted Pendulum Sytem in MATLAB Simulink
BY JITENDRA SINGH
TO RUN SIMULATION, FIRST:
1. open Init_Setup_LQRArd.m file in MATLAB and RUN it
2. this will calculate gains & initilize all parameters 
3. To Simulate Swing Up & LQR Control RUN IP_SwingUp_Design.slx file in Simulink.
4. For 3d Animation Visualization go to IP_SwingUp_Design/3D Animation block and click on VR Sink Block.
FOR INFORMATION Visit: 
DOCUMENT: https://drive.google.com/file/d/1W2v3wKXBVW4FohB33kTv8iBEiOFgoS8d/view
YouTube Playlist: https://www.youtube.com/watch?v=OwztCYKkG_o&list=PLaG3rSN23NKrxD0JvVlPguZEdHsfbitl3